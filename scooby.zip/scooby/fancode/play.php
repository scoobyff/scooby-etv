<?php
// Get match ID from URL parameter
$matchId = $_GET['id'] ?? null;

// Function to fetch and parse JSON data
function fetchMatchData() {
    $apiURL = 'https://raw.githubusercontent.com/drmlive/fancode-live-events/refs/heads/main/fancode.json';
    $jsonData = file_get_contents($apiURL);
    return json_decode($jsonData, true);
}

// Initialize variables
$match = null;
$error = null;

// Try to fetch match data if we have an ID
if ($matchId) {
    try {
        $data = fetchMatchData();
        if (isset($data['matches'])) {
            // Find the match with corresponding match_id
            foreach ($data['matches'] as $m) {
                if ((string)$m['match_id'] === (string)$matchId) {
                    $match = $m;
                    break;
                }
            }
        }
    } catch (Exception $e) {
        $error = "Error loading match data: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Fancode</title>
    <link rel="icon" href="https://www.fancode.com/skillup-uploads/fc-web-logo/favicon.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://content.jwplatform.com/libraries/SAHhwvZq.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #000;
            font-family: 'Arial', sans-serif;
            overflow-x: hidden;
            color: #fff;
            position: relative;
            min-height: 100vh;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, #000000, #0a0a0a);
            z-index: -1;
        }

        #player-container {
            width: 100%;
            aspect-ratio: 16/9;
            position: relative;
            top: 0;
            z-index: 1;
            border: 2px solid #00c2ff;
            box-shadow: 0 0 20px #00c2ff, 0 0 40px rgba(0, 194, 255, 0.5);
            box-sizing: border-box;
        }

        .content-wrapper {
            position: relative;
            width: 100%;
            z-index: 2;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-top: 20px;
        }

        .telegram-btn {
            display: inline-block;
            background: linear-gradient(90deg, #0088cc, #00c2ff);
            color: white;
            padding: 12px 28px;
            margin: 20px 0;
            border-radius: 50px;
            text-decoration: none;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
            border: none;
            cursor: pointer;
            box-shadow: 0 0 15px rgba(0, 136, 204, 0.7);
            transition: all 0.3s ease;
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 100;
        }

        .telegram-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 0 25px rgba(0, 255, 255, 0.9);
        }

        .telegram-btn i {
            margin-right: 8px;
        }

        /* Watermark styles */
        .watermark {
            position: fixed;
            bottom: 20px;
            left: 0;
            width: 100%;
            height: 30px;
            overflow: hidden;
            z-index: 99;
            pointer-events: none;
        }

        .watermark-text {
            position: absolute;
            white-space: nowrap;
            font-size: 18px;
            font-weight: bold;
            color: rgba(0, 194, 255, 0.8);
            text-shadow: 0 0 10px rgba(0, 194, 255, 0.5);
            animation: scrollHorizontal 15s linear infinite;
        }

        @keyframes scrollHorizontal {
            0% {
                transform: translateX(100%);
            }
            100% {
                transform: translateX(-100%);
            }
        }

        .jwplayer {
            position: relative!important;
            width: 100%!important;
            height: auto!important;
        }

        /* Make sure JW player controls are visible */
        .jw-state-idle .jw-controls,
        .jwplayer .jw-controls {
            opacity: 1 !important;
            visibility: visible !important;
            pointer-events: auto !important;
        }

        /* Custom scrollbar styles */
        body::-webkit-scrollbar {
            width: 8px;
            background-color: rgba(0, 0, 0, 0.7);
        }

        body::-webkit-scrollbar-thumb {
            border-radius: 10px;
            background-color: rgba(0, 194, 255, 0.5);
        }

        body::-webkit-scrollbar-thumb:hover {
            background-color: rgba(0, 194, 255, 0.7);
        }

        /* Neon pulse animation for player border */
        @keyframes neonPulse {
            0% {
                box-shadow: 0 0 10px #00c2ff, 0 0 20px rgba(0, 194, 255, 0.5);
            }
            50% {
                box-shadow: 0 0 15px #00c2ff, 0 0 30px rgba(0, 194, 255, 0.7);
            }
            100% {
                box-shadow: 0 0 10px #00c2ff, 0 0 20px rgba(0, 194, 255, 0.5);
            }
        }

        #player-container {
            animation: neonPulse 3s infinite ease-in-out;
        }

        #message {
            color: #fff;
            align-items: center;
            z-index: 1001;
            display: flex;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            justify-content: center;
            font-size: 24px;
        }

        @media (max-width: 768px) {
            .telegram-btn {
                padding: 10px 20px;
                font-size: 14px;
            }
            
            .watermark-text {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <div id="player-container"></div>
    
    <div class="content-wrapper">
        <!-- Content area after the video if needed -->
    </div>

    <!-- Watermark -->
    <div class="watermark">
        <div class="watermark-text">Scooby Streams</div>
    </div>

    <a href="#" class="telegram-btn" id="telegram-btn">
        <i class="fab fa-telegram"></i> Join Telegram
    </a>
    
    <?php if ($error): ?>
        <div id="message"><?php echo htmlspecialchars($error); ?></div>
    <?php elseif (!$match): ?>
        <div id="message">Match not found</div>
    <?php else: ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const player = jwplayer("player-container").setup({
                    file: <?php echo json_encode($match['adfree_url']); ?>,
                    width: "100%",
                    height: "56.25%", // 16:9 aspect ratio (9/16 * 100)
                    autostart: true,
                    mute: false,
                    primary: "html5",
                    hlshtml: true,
                    aspectratio: "16:9",
                    stretching: "uniform",
                    playbackRateControls: true,
                    controls: true,
                });
                
                // Force controls to be visible and fix player size
                player.on('ready', function() {
                    player.setMute(false);
                    player.setVolume(100);
                    
                    // Set a timeout to ensure controls are visible after initialization
                    setTimeout(function() {
                        const jwControls = document.querySelector('.jw-controls');
                        if (jwControls) {
                            jwControls.style.opacity = '1';
                            jwControls.style.visibility = 'visible';
                            jwControls.style.pointerEvents = 'auto';
                        }
                    }, 1000);
                });
                
                // Handle autoplay with sound
                player.on('play', function() {
                    player.setMute(false);
                    player.setVolume(100);
                    document.body.style.backgroundColor = "#000";
                });

                // Ensure controls are visible when user taps
                document.addEventListener('click', function() {
                    const jwControls = document.querySelector('.jw-controls');
                    if (jwControls) {
                        jwControls.style.opacity = '1';
                        jwControls.style.visibility = 'visible';
                        jwControls.style.pointerEvents = 'auto';
                    }
                });

                player.on('error', function (e) {
                    console.error("Playback error:", e.message);
                });
            });

            // Telegram button functionality
            document.getElementById('telegram-btn').addEventListener('click', function(e) {
                e.preventDefault();
                // Replace with your actual Telegram link
                // window.open('https://t.me/scoobystream', '_blank');
                alert('Please Join Our Telegram Channels for links');
            });
        </script>
    <?php endif; ?>
</body>
</html>
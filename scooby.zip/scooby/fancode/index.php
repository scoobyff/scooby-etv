<?php
// Referrer validation
function validateReferrer() {
    $allowed_referrers = [
        'scoobystreams.vercel.app',
        'scoobyff.github.io'
    ];
    
    $referrer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
    
    if (empty($referrer)) {
        return false; // No referrer means direct access
    }
    
    $referrer_host = parse_url($referrer, PHP_URL_HOST);
    
    if (!$referrer_host) {
        return false;
    }
    
    // Check if referrer matches allowed domains
    foreach ($allowed_referrers as $allowed) {
        if ($referrer_host === $allowed || str_ends_with($referrer_host, '.' . $allowed)) {
            return true;
        }
    }
    
    return false;
}

// Check access permission
$has_access = validateReferrer();

// If no access, show access denied page
if (!$has_access) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <title>Access Restricted - Fancode</title>
        <link rel="icon" href="https://www.fancode.com/skillup-uploads/fc-web-logo/favicon.png" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
            
            body {
                font-family: 'Inter', sans-serif;
                background: linear-gradient(135deg, #0f0f23 0%, #1a1a3a 50%, #2d1b69 100%);
                color: #ffffff;
                min-height: 100vh;
            }
            
            .access-denied-container {
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
                padding: 2rem;
            }
            
            .access-denied-card {
                background: rgba(255, 255, 255, 0.05);
                backdrop-filter: blur(20px);
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 24px;
                padding: 3rem;
                text-align: center;
                max-width: 500px;
                width: 100%;
            }
            
            .error-icon {
                font-size: 4rem;
                color: #ef4444;
                margin-bottom: 1.5rem;
                animation: pulse 2s infinite;
            }
            
            @keyframes pulse {
                0%, 100% { opacity: 1; }
                50% { opacity: 0.5; }
            }
        </style>
    </head>
    <body>
        <div class="access-denied-container">
            <div class="access-denied-card">
                <div class="error-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <h1 class="text-3xl font-bold mb-4 text-red-400">Access Restricted</h1>
                <p class="text-gray-300 mb-6">
                    This content is only accessible through authorized channels. 
                    Direct access is not permitted.
                </p>
                <div class="text-sm text-gray-500">
                    <i class="fas fa-info-circle mr-2"></i>
                    Open it from website https://scoobystreams.vercel.app 
                </div>
            </div>
        </div>
        
        <script>
            // Additional security measures
            
            // Disable right-click
            document.addEventListener('contextmenu', function(e) {
                e.preventDefault();
            });
            
            // Disable F12, Ctrl+Shift+I, Ctrl+U
            document.addEventListener('keydown', function(e) {
                if (e.key === 'F12' || 
                    (e.ctrlKey && e.shiftKey && e.key === 'I') ||
                    (e.ctrlKey && e.key === 'u')) {
                    e.preventDefault();
                }
            });
            
            // Clear console
            setInterval(function() {
                console.clear();
            }, 1000);
        </script>
    </body>
    </html>
    <?php
    exit();
}

// Original code continues here only if access is granted...

// Fetch match data from API
function fetchMatchData() {
    $api_url = 'https://raw.githubusercontent.com/drmlive/fancode-live-events/refs/heads/main/fancode.json';
    
    // Use cURL for better error handling
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($response === false || $http_code !== 200) {
        return null;
    }
    
    $data = json_decode($response, true);
    return $data;
}

// Generate match cards HTML
function generateMatchCards($matches) {
    if (empty($matches)) {
        return '
            <div class="col-span-full text-center py-20 space-y-6">
                <div class="text-8xl text-gray-400"><i class="fas fa-satellite-dish"></i></div>
                <h3 class="text-3xl font-bold text-gray-300">No Live Events</h3>
                <p class="text-gray-400 text-lg">Check back soon for exciting live sports action</p>
            </div>';
    }
    
    $html = '';
    foreach ($matches as $match) {
        $live_indicator = '';
        if ($match['status'] === 'LIVE') {
            $live_indicator = '
                <div class="live-indicator">
                    <div class="live-dot"></div>
                    <span>LIVE</span>
                </div>';
        }
        
        $watch_button = '';
        if ($match['status'] === 'LIVE') {
            $watch_button = '
                <button class="watch-btn w-full flex items-center justify-center space-x-2" onclick="window.location.href=\'./play.php?id=' . htmlspecialchars($match['match_id']) . '\'">
                    <i class="fas fa-play-circle"></i>
                    <span>Watch Live</span>
                </button>';
        } else {
            $watch_button = '
                <button class="watch-btn disabled-btn w-full flex items-center justify-center space-x-2" disabled>
                    <i class="fas fa-clock"></i>
                    <span>Starting Soon</span>
                </button>';
        }
        
        $start_time = explode(' ', $match['startTime'])[0];
        
        $html .= '
            <article class="match-card group">
                ' . $live_indicator . '
                
                <div class="match-image aspect-video relative">
                    <img src="' . htmlspecialchars($match['src']) . '" alt="' . htmlspecialchars($match['title']) . '" class="w-full h-full object-cover" loading="lazy">
                    <div class="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                </div>
                
                <div class="match-content">
                    <div class="flex items-center justify-between mb-4">
                        <span class="category-badge">' . htmlspecialchars($match['event_category']) . '</span>
                        <div class="text-sm text-gray-400">
                            <i class="fas fa-clock mr-1"></i>
                            ' . htmlspecialchars($start_time) . '
                        </div>
                    </div>
                    
                    <h3 class="text-xl font-bold mb-2 text-white group-hover:text-indigo-300 transition-colors">
                        ' . htmlspecialchars($match['event_name']) . '
                    </h3>
                    
                    <div class="team-vs">
                        <div class="flex items-center justify-center space-x-4">
                            <span class="text-sm font-semibold text-center flex-1">' . htmlspecialchars($match['team_1']) . '</span>
                            <div class="w-8 h-8 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 flex items-center justify-center">
                                <span class="text-xs font-bold">VS</span>
                            </div>
                            <span class="text-sm font-semibold text-center flex-1">' . htmlspecialchars($match['team_2']) . '</span>
                        </div>
                    </div>
                    
                    <div class="mt-6">
                        ' . $watch_button . '
                    </div>
                </div>
            </article>';
    }
    
    return $html;
}

// Fetch data
$match_data = fetchMatchData();
$matches_html = '';
$error_message = '';

if ($match_data === null) {
    $error_message = '
        <div class="col-span-full text-center py-20 space-y-6">
            <div class="text-8xl text-red-400"><i class="fas fa-exclamation-triangle"></i></div>
            <h3 class="text-3xl font-bold text-gray-300">Connection Error</h3>
            <p class="text-gray-400 text-lg">Unable to load live events. Please try again.</p>
            <button onclick="location.reload()" class="watch-btn mt-4">
                <i class="fas fa-refresh mr-2"></i>
                Retry
            </button>
        </div>';
} else {
    $matches = isset($match_data['matches']) ? $match_data['matches'] : [];
    $matches_html = generateMatchCards($matches);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Fancode</title>
    <link rel="icon" href="https://www.fancode.com/skillup-uploads/fc-web-logo/favicon.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
    
    :root {
      --primary: #6366f1;
      --secondary: #a855f7;
      --accent: #ec4899;
      --success: #10b981;
      --warning: #f59e0b;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Inter', sans-serif;
      background: linear-gradient(135deg, #0f0f23 0%, #1a1a3a 50%, #2d1b69 100%);
      color: #ffffff;
      min-height: 100vh;
      overflow-x: hidden;
    }

    .glass-effect {
      background: rgba(255, 255, 255, 0.05);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .floating-particles {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 1;
    }

    .particle {
      position: absolute;
      background: radial-gradient(circle, rgba(99, 102, 241, 0.4) 0%, transparent 70%);
      border-radius: 50%;
      animation: float 20s infinite linear;
    }

    @keyframes float {
      0% { transform: translateY(100vh) rotate(0deg); opacity: 0; }
      10% { opacity: 1; }
      90% { opacity: 1; }
      100% { transform: translateY(-100vh) rotate(360deg); opacity: 0; }
    }

    .hero-section {
      background: linear-gradient(135deg, rgba(99, 102, 241, 0.1) 0%, rgba(168, 85, 247, 0.1) 100%);
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .match-card {
      position: relative;
      background: rgba(255, 255, 255, 0.03);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 24px;
      overflow: hidden;
      transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      transform-style: preserve-3d;
    }

    .match-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(135deg, rgba(99, 102, 241, 0.1) 0%, rgba(236, 72, 153, 0.1) 100%);
      opacity: 0;
      transition: opacity 0.3s ease;
      z-index: 1;
    }

    .match-card:hover {
      transform: translateY(-12px) rotateX(5deg) rotateY(5deg);
      box-shadow: 
        0 25px 50px rgba(0, 0, 0, 0.25),
        0 0 100px rgba(99, 102, 241, 0.2);
      border-color: rgba(99, 102, 241, 0.3);
    }

    .match-card:hover::before {
      opacity: 1;
    }

    .match-image {
      position: relative;
      overflow: hidden;
    }

    .match-image img {
      transition: transform 0.5s ease;
    }

    .match-card:hover .match-image img {
      transform: scale(1.1);
    }

    .live-indicator {
      position: absolute;
      top: 16px;
      left: 16px;
      background: linear-gradient(135deg, #ef4444, #dc2626);
      color: white;
      padding: 8px 16px;
      border-radius: 50px;
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      box-shadow: 0 4px 20px rgba(239, 68, 68, 0.4);
      z-index: 10;
      display: flex;
      align-items: center;
    }

    .live-dot {
      width: 8px;
      height: 8px;
      background: white;
      border-radius: 50%;
      animation: livePulse 1.5s infinite;
      margin-right: 8px;
      flex-shrink: 0;
    }

    @keyframes livePulse {
      0%, 100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.5; transform: scale(1.2); }
    }

    .match-content {
      position: relative;
      z-index: 2;
      padding: 24px;
    }

    .category-badge {
      background: linear-gradient(135deg, var(--primary), var(--secondary));
      color: white;
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      display: inline-block;
    }

    .watch-btn {
      background: linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%);
      border: none;
      color: white;
      padding: 14px 28px;
      border-radius: 50px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      transition: all 0.3s ease;
      position: relative;
      overflow: hidden;
      box-shadow: 0 8px 30px rgba(99, 102, 241, 0.3);
    }

    .watch-btn::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
      transition: left 0.5s ease;
    }

    .watch-btn:hover::before {
      left: 100%;
    }

    .watch-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 12px 40px rgba(99, 102, 241, 0.4);
    }

    .disabled-btn {
      background: linear-gradient(135deg, #374151, #4b5563);
      color: #9ca3af;
      cursor: not-allowed;
      box-shadow: none;
    }

    .disabled-btn:hover {
      transform: none;
      box-shadow: none;
    }

    .team-vs {
      background: rgba(255, 255, 255, 0.05);
      padding: 16px;
      border-radius: 16px;
      margin: 16px 0;
      border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .floating-nav {
      position: fixed;
      top: 24px;
      left: 50%;
      transform: translateX(-50%);
      background: rgba(255, 255, 255, 0.05);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 50px;
      padding: 12px 32px;
      z-index: 100;
      transition: all 0.3s ease;
    }

    .floating-nav:hover {
      background: rgba(255, 255, 255, 0.08);
      transform: translateX(-50%) translateY(-2px);
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
    }

    .scroll-indicator {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 4px;
      background: linear-gradient(90deg, var(--primary), var(--accent));
      transform-origin: left;
      transform: scaleX(0);
      z-index: 1000;
      transition: transform 0.3s ease;
    }

    @media (max-width: 768px) {
      .match-card:hover {
        transform: translateY(-8px);
      }
    }
  </style>
</head>
<body>
  <div class="floating-particles" id="particles"></div>
  <div class="scroll-indicator" id="scrollIndicator"></div>
  
  <nav class="floating-nav">
    <div class="flex items-center space-x-4">
      <div class="w-8 h-8 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 flex items-center justify-center">
        <i class="fas fa-play text-white text-sm"></i>
      </div>
      <h1 class="text-lg font-bold bg-gradient-to-r from-indigo-400 to-pink-400 bg-clip-text text-transparent">
        Fancode Live
      </h1>
    </div>
  </nav>

  <main class="pt-32 pb-20 px-6">
    <div class="max-w-7xl mx-auto">
      <div id="matches-container" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        <?php echo $error_message ?: $matches_html; ?>
      </div>
    </div>
  </main>

  <button id="backToTop" class="fixed bottom-8 right-8 w-14 h-14 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white rounded-full shadow-2xl backdrop-blur-sm transition-all opacity-0 invisible hover:scale-110" aria-label="Back to top">
    <i class="fas fa-rocket"></i>
  </button>

  <script>
    // Create floating particles
    function createParticles() {
      const particlesContainer = document.getElementById('particles');
      const particleCount = 20;
      
      for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.width = particle.style.height = Math.random() * 6 + 2 + 'px';
        particle.style.animationDelay = Math.random() * 20 + 's';
        particle.style.animationDuration = Math.random() * 20 + 20 + 's';
        particlesContainer.appendChild(particle);
      }
    }

    // Scroll indicator
    function updateScrollIndicator() {
      const scrollPercent = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
      document.getElementById('scrollIndicator').style.transform = `scaleX(${scrollPercent / 100})`;
    }

    // Frame buster protection
    if (window.top !== window.self) {
      window.addEventListener('DOMContentLoaded', function() {
        document.body.innerHTML = '<div class="flex items-center justify-center min-h-screen text-2xl">Access Denied</div>';
      });
    }

    // Back to Top Button
    const backToTop = document.getElementById('backToTop');
    window.addEventListener('scroll', () => {
      updateScrollIndicator();
      
      if (window.scrollY > 500) {
        backToTop.classList.remove('opacity-0', 'invisible');
        backToTop.classList.add('opacity-100', 'visible');
      } else {
        backToTop.classList.remove('opacity-100', 'visible');
        backToTop.classList.add('opacity-0', 'invisible');
      }
    });

    backToTop.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // Additional security measures for authorized access
    
    // Disable right-click
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
    });
    
    // Disable F12, Ctrl+Shift+I, Ctrl+U
    document.addEventListener('keydown', function(e) {
        if (e.key === 'F12' || 
            (e.ctrlKey && e.shiftKey && e.key === 'I') ||
            (e.ctrlKey && e.key === 'u')) {
            e.preventDefault();
        }
    });

    // Initialize
    createParticles();
    updateScrollIndicator();
  </script>
</body>
</html>